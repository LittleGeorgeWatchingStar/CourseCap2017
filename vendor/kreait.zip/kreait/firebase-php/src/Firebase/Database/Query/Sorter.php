<?php

namespace Kreait\Firebase\Database\Query;

interface Sorter extends Modifier
{
}
