<?php

namespace Kreait\Firebase\Exception;

class PermissionDenied extends ApiException
{
}
