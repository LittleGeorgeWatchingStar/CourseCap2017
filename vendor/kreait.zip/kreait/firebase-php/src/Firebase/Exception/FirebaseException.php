<?php

namespace Kreait\Firebase\Exception;

interface FirebaseException extends \Throwable
{
}
