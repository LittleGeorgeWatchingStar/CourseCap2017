#### 1. Which version of `kreait/firebase-php` are you using?

*You can use `composer show kreait/firebase-php` to see the installed version in the `versions` line.*

#### 2. Which version of PHP are you using?

*You can use `php -v` on the system the issue occurs on to get the PHP version.* 

#### 3. What's the issue?

*Please don't just copy and paste a PHP exception trace.*

#### 4. Code that lead to the issue

*Please use [syntax highlighted code blocks](https://help.github.com/articles/creating-and-highlighting-code-blocks/) with code that can be used to reproduce the issue.*

